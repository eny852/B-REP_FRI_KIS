#include <vector>
#include <map>
#include <string.h>

#include "inet/common/INETDefs.h"
#include "inet/networklayer/common/InterfaceEntry.h"

typedef std::string Bitstring;

namespace inet {

namespace ospf {

    class INET_API BREPBackupTableEntry
    {
    public:
        IPv4Address nhop;
        std::string ipaddr;
        std::string destBREPid;
        Bitstring bitstring;
        InterfaceEntry* iface;

        BREPBackupTableEntry(IPv4Address paNhop, std::string paIpaddr, std::string paDestBREPid, Bitstring paBitstring, InterfaceEntry* paIface);
    };
    std::ostream& operator<<(std::ostream& out, BREPBackupTableEntry& entry);
}

}
