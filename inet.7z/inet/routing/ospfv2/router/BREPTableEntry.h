#include <vector>
#include <map>
#include <string.h>

#include "inet/routing/ospfv2/router/OSPFcommon.h"
#include "inet/networklayer/common/InterfaceEntry.h"

typedef std::string Bitstring;

namespace inet {

namespace ospf {

    class INET_API BREPTableEntry
    {
    public:
        RouterID Router_ID;
        Bitstring BREP_ID;

        BREPTableEntry(RouterID Router_ID, Bitstring BREP_ID);
        BREPTableEntry();
    };
    std::ostream& operator<<(std::ostream& out, BREPTableEntry& entry);
}

}
