#include "inet\routing\ospfv2\router\BREPTableEntry.h"

namespace inet {

namespace ospf {

    BREPTableEntry::BREPTableEntry(RouterID paRouter_ID, Bitstring paBREP_ID) {
        Router_ID = paRouter_ID;
        BREP_ID = paBREP_ID;
    }

    BREPTableEntry::BREPTableEntry(){

    }

    std::ostream& operator<<(std::ostream& out, BREPTableEntry& entry)
    {
        out << "RouterID: " << entry.Router_ID.str() << " | ";                                                             //TOTO
        out << "B-REP R-ID: " << entry.BREP_ID;
        return out;
    }

}

}
