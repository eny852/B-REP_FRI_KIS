#include "inet\routing\ospfv2\router\BREPBackupTableEntry.h"

namespace inet {

namespace ospf {

    BREPBackupTableEntry::BREPBackupTableEntry(IPv4Address paNhop, std::string paIpaddr, std::string paDestBREPid, Bitstring paBitstring, InterfaceEntry* paIface){
        nhop = paNhop;
        ipaddr = paIpaddr;
        destBREPid = paDestBREPid;
        bitstring = paBitstring;
        iface = paIface;
    }

    std::ostream& operator<<(std::ostream& out, BREPBackupTableEntry& entry)
    {
        out << "nhop: " << entry.nhop.str() << " | ";                                                             //TOTO
        out << "dest: " << entry.ipaddr << " | ";
        out << "dest BREP id: " << entry.destBREPid << " | ";
        out << "bitstring: " << entry.bitstring;
        return out;
    }

}

}
